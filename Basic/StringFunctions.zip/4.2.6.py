#to change the case of the string
str='global variable'
print(str.upper())
