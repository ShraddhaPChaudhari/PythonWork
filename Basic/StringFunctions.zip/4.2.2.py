#to display substring starting from index 4 and ending at index 8
s='global variable'
print(s[4:9])
