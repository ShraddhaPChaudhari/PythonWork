#to display last 4 characters
a='global variable'
print(a[11: ])
