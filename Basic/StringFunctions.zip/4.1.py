# write a program to accept string maharashtra except letter a.
s='maharashtra'
for i in s:
    if(i=='a'):
        continue
    print(i)
    
