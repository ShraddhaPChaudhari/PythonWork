#to replace all occurances of letter a with o.
str='global variable'
print(str.replace('a' , 'o'))
