#to accept string and rremove all punctuation of string
s=(' "OMG! This is really surprise". ')
print(s,'/nThe sentence after after removing punctuation:')
import string
for c in (string.punctuation):
    s=s.replace(c, " ")
print(s)
