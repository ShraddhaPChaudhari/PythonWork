#accept the string and count number of vowels
my_str=input("enter a string: ")
a=my_str.count("a")
e=my_str.count("e")
i=my_str.count("i")
o=my_str.count("o")
u=my_str.count("u")
print("total vowels=" , a+e+i+o+u)
