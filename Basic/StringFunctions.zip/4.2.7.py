#to check whether a string is in titlecase or not?
a='global variable'
print(a.istitle())
if(a==1):
    print(‘a is in titlecase’)
else:
    (‘a is not in titlecase’)	
    
    
