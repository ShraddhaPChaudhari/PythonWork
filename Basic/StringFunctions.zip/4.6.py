#accept the string and sort the string alphabetically
a=input("enter a string to sort it in alphabetical order: ")
print(''.join(sorted(a)))
