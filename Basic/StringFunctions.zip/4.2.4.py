#to trim last 4 characters  from the string
str='global variable'
print(str[:-4].strip())
