# to check  whether a string has alphanumeric character or not?
s='abc123'
res=s.isalpha()
if(res==1):
    print('alphanumeric string')
else:
    print('no alphanumeric string')
