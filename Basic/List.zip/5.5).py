#program to perform substraction of multidimensional array
A=[[65,34,87],
     [45,32,56],
     [23,67,43]]
B=[[12,45,62],
     [19,32,24],
     [33,46,18]]
ans=[[0,0,0],
       [0,0,0],
       [0,0,0]]
for i in range(len(A)):
    for j in range(len(A[0])):
        ans[i][j]=A[i][j]-B[i][j]
for a in ans:
    print(a)
        
