#two accept nmx matrix from user and find thier sum
rows=int(input("Enter the number of rows "))
cols=int(input("Enter the number of columns "))
matrix = [[0]*cols for x in range(rows)]

for i in range (rows):
    for j in range (cols):
        matrix[i][j]=(input("Enter the element "))
print(matrix)
