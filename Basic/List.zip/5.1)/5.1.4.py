#add two more friends in the begining of the list using + operator
mylist=['shraddha', 'Archana', 'Rachana', 'vinoti', 'nikita']
print(mylist)
mylist1=['ruchita', 'Raman']
print(mylist1)
list1=mylist1+mylist
print(list1)
