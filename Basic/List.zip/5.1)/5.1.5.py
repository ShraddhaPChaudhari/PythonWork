#create a copy of list in reverse order
mylist=['shraddha', 'Archana', 'Rachana', 'vinoti', 'nikita']
print(mylist)
mylist.reverse()
print(mylist)
