#print the given list
mylist=['shraddha', 'Archana', 'Rachana', 'vinoti', 'nikita']
print(mylist)
for i in mylist:
    print (i)
