#ask the user about position and display the name of friend with given position
mylist=['shraddha', 'Archana', 'Rachana', 'vioti', 'nikita']
print(mylist)
pos=int(input("Please enter the position whose name you want "))
print(mylist[pos-1])
