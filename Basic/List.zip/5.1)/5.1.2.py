#ask user to add new list in a list
mylist=['shraddha', 'Archana', 'Rachana', 'vinoti', 'nikita']
print(mylist)
mylist.append(input("Please enter a name to add in the list "))
print(mylist)
