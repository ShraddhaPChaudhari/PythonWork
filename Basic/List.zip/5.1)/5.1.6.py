#remove the last element from list
mylist=['shraddha', 'Archana', 'Rachana', 'vinoti', 'nikita']
print(mylist)
mylist.remove('nikita')
print(mylist)
