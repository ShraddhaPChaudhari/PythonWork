#ask the user friend name to delete the list. if name exists then delete otherwise display appropriate message
mylist=['shraddha', 'Archana', 'Rachana', 'vinoti', 'nikita']
print(mylist)
x=input("Enter the name you want to delete ")
for i in mylist:
    if x==i:
      mylist.remove(i)
print(mylist)
