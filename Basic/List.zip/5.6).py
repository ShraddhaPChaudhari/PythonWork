#program to find transpose of the matrix
matrix = [[12,7,13],
              [4,5,16],
              [3,8,32]]
result = [[0,0,0],
             [0,0,0],
             [0,0,0]]
for i in range(len(matrix)):
   for j in range(len(matrix[0])):
       result[j][i] = matrix[i][j]

for r in result:
   print(r)
