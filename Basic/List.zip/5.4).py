#proogram to perform addition of one dimensional matrix/array
a=[6,5,2]
b=[4,5,6]
ans=[0,0,0]
for i in range(len(a)):
       ans[i] = a[i] + b[i]
print (ans)
