#program to input n employees salary and find minimum and maximum  salary for n employee
mylist=[]
num=int(input("Enter the number of employees "))
for i in range(num):
    mylist.append(input("Please enter the salary for Employees " ))
print ("The maximum salary is ", max(mylist))
print ("The minimum salary is ", min(mylist))
