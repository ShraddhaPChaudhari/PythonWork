#'fro software program create dictionary and display it
company={'software company name': 'LNT', 'Date of install':'04.01.2016', 'User name':'Sharddha', 'Turn over':12000000, 'client names':['Devshree', 'Ruchita', 'Purva', 'Nikita']}
print(company.items())
