#create dictionary to store FYBsc (teacher, subject names) & display the details
print('\t@@@@ FYBsc. subjects & teachers information @@@@')
teacher={'Rasika':'Python','Mahavir':'FOSS','Edith':'Discrete maths','Pooja':'COD'}
for t, s in teacher.items():
    print(t,'-',s)
