#create dictionary to store information about 5 employees and display it in ascending order based on id
print("Information about 5 employees : ")
employee={'Sanika':30, 'manali':20, 'kajal':9, 'Sajal':31, 'Mohit':9}
a=print(sorted(employee.values()))




