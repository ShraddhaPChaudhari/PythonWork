#for course create dictionary and store information of 3 courses
coursea={'fee structure':40000, 'tuitor name':'shivam chaudhari', 'venue':'Dadar', 'Timings':'9.00am'}
courseb={'fee structure':50000, 'tuitor name':'Shraddha Parab', 'venue':'worli', 'Timings':'10.00am'}
coursec={'fee structure':60000, 'tuitor name':'Pramod Patil', 'venue':'hindamata', 'Timings':'8.00am'}
print(coursea.items(),'\n', courseb.items(),'\n',  coursec.items())

