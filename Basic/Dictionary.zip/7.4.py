#refer company dictionary and display client names of LNT
company={'software company name': 'LNT', 'Date of install':'04.01.20016', 'User name':'Sharddha', 'Turn over':12000000, 'client names':['Ruchita', 'Devshree', 'Purva', 'Nikita']}
print(company.get('client names'))
