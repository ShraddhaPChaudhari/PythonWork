#create a dictionary for names of products and its price and display the chipest ans costiest product from dictionary
name={'pc':40000, 'cell':20000, 'laptop':35000, 'printer':7000, 'desktop':5000}
print(max(name.values()))
print(min(name.values()))
