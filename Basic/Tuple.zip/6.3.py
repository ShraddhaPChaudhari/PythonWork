# create a touple to store drawing information
a=('still life')
b=['black','blue','purple','green']
c=['shraddha','manali']
d=(a,b,c,)
print('drawing=',d)




