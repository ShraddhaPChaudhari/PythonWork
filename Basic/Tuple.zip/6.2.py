# tuple which contain names of month and display the month of christmas
a=('january,february,march,april,may,june,july,august,september,october,november,december')
m=a[-8: ]
print('the month of christmas is',m)

