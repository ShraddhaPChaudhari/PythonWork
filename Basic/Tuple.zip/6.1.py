#Using tuple comtaining list of colleges offering computer science
a=('ruia college,ruparel college,kirti college,SNDT college,khalsa college',)
s=type(a)
print(s)
print('List of colleges offering computer science:',a)
