#packing and unpacking of touple
(a,b)=('taj mahal','agra',)
(monument,place)=(a,b)
print('monument:',a,)
print('place:',b)
