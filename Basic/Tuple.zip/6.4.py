#add new artist in tuple
drawing= ('still life', ['black', 'blue', 'purple', 'green'], ['shraddha', 'manali'])
d=drawing[-1]
x=input('enter the new artist')
d.append(x)
print(drawing)
