#display status from tuesday to friday
status=('monday:busy','tuesday:sleeping','wednesday:avialable','thursday:happy','friday:feeling luck','saturday:at work','sunday:enjoying',)
x=status[1:5]
print(x)
